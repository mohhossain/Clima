package com.londonappbrewery.climapm;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class WeatherDataModel {

    // TODO: Declare the member variables here
    private String mTemparatureC;
    private String mTemparatureF;
    private int mCondition;
    private String mCity;
    private String mIconName;
    private String mMinC;
    private String mMinF;
    private String mMaxC;
    private String mMaxF;
    private String mCountry;
    private String mSpeed;
    private String mHumidity;

    // TODO: Create a WeatherDataModel from a JSON:


    public static WeatherDataModel fromJson (JSONObject jsonObject){
        WeatherDataModel weatherDataModel = new WeatherDataModel();

        try {
            weatherDataModel.mCity = jsonObject.getString("name");
            weatherDataModel.mCondition = jsonObject.getJSONArray("weather").getJSONObject(0).getInt("id");
            weatherDataModel.mCountry = jsonObject.getJSONObject("sys").getString("country");

            int minF = (int) Math.rint(jsonObject.getJSONObject("main").getDouble("temp_min") - 273.15);
            int minC = (int) Math.rint(minF * 9.0/5.0 + 32);
            weatherDataModel.mMinC = Integer.toString(minC);
            weatherDataModel.mMinF = Integer.toString(minF);
            int maxF =(int) Math.rint(jsonObject.getJSONObject("main").getDouble("temp_max") - 273.15);
            int maxC =(int) Math.rint(maxF * 9.0/5.0 + 32);
            weatherDataModel.mMaxC = Integer.toString(maxC);
            weatherDataModel.mMaxF = Integer.toString(maxF);

            weatherDataModel.mIconName = updateWeatherIcon(weatherDataModel.mCondition);

            double tempResult = jsonObject.getJSONObject("main").getDouble("temp") - 273.15;
            double tempFar = tempResult * 9.0 / 5.0 + 32;

            int tempCel = (int) Math.rint(tempResult);
            int tempFaren = (int) Math.rint(tempFar);

            weatherDataModel.mTemparatureC = Integer.toString(tempCel);
            weatherDataModel.mTemparatureF = Integer.toString(tempFaren);

            long mSunrise = jsonObject.getJSONObject("sys").getLong("sunrise");
            long mSunset = jsonObject.getJSONObject("sys").getLong("sunset");

            String rise = ConvertMilliSecondsToFormattedDate(mSunrise);
            Log.d("clima", "fromJson: rise" + rise);

            weatherDataModel.mSpeed = jsonObject.getJSONObject("wind").getString(String.valueOf("speed"));
            weatherDataModel.mHumidity = jsonObject.getJSONObject("main").getString(String.valueOf("humidity"));


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return weatherDataModel;
    }

    public static String dateFormat = "dd-MM-yyyy hh:mm";
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);

    public static String ConvertMilliSecondsToFormattedDate(long milliSeconds){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Long.parseLong(String.valueOf(milliSeconds)));
        return simpleDateFormat.format(calendar.getTime());
    }


    // TODO: Uncomment to this to get the weather image name from the condition:
    private static String updateWeatherIcon(int condition) {

        if (condition >= 0 && condition < 300) {
            return "tstorm1";
        } else if (condition >= 300 && condition < 500) {
            return "light_rain";
        } else if (condition >= 500 && condition < 600) {
            return "shower3";
        } else if (condition >= 600 && condition <= 700) {
            return "snow4";
        } else if (condition >= 701 && condition <= 771) {
            return "fog";
        } else if (condition >= 772 && condition < 800) {
            return "tstorm3";
        } else if (condition == 800) {
            return "sunny";
        } else if (condition >= 801 && condition <= 804) {
            return "cloudy2";
        } else if (condition >= 900 && condition <= 902) {
            return "tstorm3";
        } else if (condition == 903) {
            return "snow5";
        } else if (condition == 904) {
            return "sunny";
        } else if (condition >= 905 && condition <= 1000) {
            return "tstorm3";
        }

        return "dunno";
    }

    // TODO: Create getter methods for temperature, city, and icon name:


    public String getTemparatureC() {
        return mTemparatureC + "°";
    }

    public String getTemparatureF() {
        return mTemparatureF + "°";
    }

    public int getCondition() {
        return mCondition;
    }

    public String getCity() {
        return mCity;
    }

    public String getIconName() {
        return mIconName;
    }

    public String getMinC() {
        return mMinC;
    }

    public String getMinF() {
        return mMinF + "°";
    }

    public String getMaxC() {
        return mMaxC + "°";
    }

    public String getMaxF() {
        return mMaxF + "°";
    }

    public String getCountry() {
        return mCountry;
    }

    public String getSpeed() {
        return mSpeed;
    }

    public String getHumidity() {
        return mHumidity;
    }
}
